# Databricks notebook source
# MAGIC %md
# MAGIC # Sales Bronze to Silver Transformation
# MAGIC
# MAGIC ## Objective
# MAGIC Transform Sales transactional data from the Bronze layer into the Silver layer by applying data quality validations, referential integrity checks, business rule validations, and business enrichments before storing the cleansed data in ADLS Gen2.
# MAGIC
# MAGIC **Source:** Bronze (CSV)
# MAGIC
# MAGIC **Destination:** Silver (Parquet)
# MAGIC
# MAGIC **Technologies:** Azure Databricks, PySpark, ADLS Gen2, Parquet

# COMMAND ----------

# MAGIC %md
# MAGIC # Sales Table Grain
# MAGIC ## One row = One sales line item within a customer order (line-level sales fact table).

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading the notebook from ADLS 

# COMMAND ----------

# DBTITLE 1,Cell 3
display(
        spark.read.option("header", "true")
        .csv("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/sales/sales_final.csv")
        )


# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating DDL Schema

# COMMAND ----------

sales_schema = '''
Sale_ID STRING,
Order_ID STRING,
Sale_DateTime TIMESTAMP,
Customer_ID STRING,
Product_ID STRING,
Store_ID STRING,
Quantity INTEGER,
Unit_Price DOUBLE,
Payment_Method STRING,
Discount_Amount DOUBLE,
Order_Status STRING
'''

print(sales_schema)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating New Dataframe with DDL schema

# COMMAND ----------

df_sales = (

    spark.read.schema(sales_schema)
    .format("csv")
    .option("header", "true")
    .load("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/sales/sales_final.csv")
)

df_sales.show(5)
df_sales.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC ### Successfully read the Sales dataset from the Bronze layer.
# MAGIC ### Applied an explicit schema to ensure correct data types.
# MAGIC ### Verified the schema and sample records.
# MAGIC ### Dataset is ready for profiling and data quality validation.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Profiling

# COMMAND ----------

# MAGIC %md
# MAGIC ### Row Count Verification

# COMMAND ----------

df_sales.count()
df_sales.select("Sale_ID").distinct().count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null Value Analysis

# COMMAND ----------

df_total_null_count= df_sales.select(
    [
        count(when(col(c).isNull(), c)).alias(c)
        for c in df_sales.columns
    ]
)
df_total_null_count.show()

# COMMAND ----------

df_dup_sales_count = df_sales.groupBy("Sale_ID").count()
df_dup_sales_count = df_dup_sales_count.filter(col("count") > 1)
df_dup_sales_count.show()

# COMMAND ----------

print(df_sales.count())

# COMMAND ----------

print(df_sales.select("Sale_ID").distinct().count())

# COMMAND ----------

print(
    df_sales.groupBy("Sale_ID")
            .count()
            .filter(col("count") > 1)
            .count()
)

# COMMAND ----------

df_sales.filter("Sale_ID = 'SALE042129'").show(truncate=False)

# COMMAND ----------

df_sales_clean = df_sales.dropDuplicates(["Sale_ID"])

df_sales_clean.show()

# COMMAND ----------

df_sales.count()


# COMMAND ----------

df_sales_clean.count()

# COMMAND ----------

df_sales.groupBy("Sale_ID") \
        .count() \
        .filter(col("count") > 1) \
        .show()

# COMMAND ----------

print("Rows:", df_sales.count())

# COMMAND ----------

print("Distinct Sale_ID:", df_sales.select("Sale_ID").distinct().count())

# COMMAND ----------

df_sales.groupBy("Sale_ID") \
        .count() \
        .filter(col("count") > 1) \
        .count()

# COMMAND ----------

print(df_sales_clean.count())

# COMMAND ----------

df_sales_clean.groupBy("Sale_ID") \
              .count() \
              .filter(col("count") > 1) \
              .count()

# COMMAND ----------

df_sales_valid_records = df_sales_clean.filter(
                                                (col("Sale_ID")).isNotNull() 
                                                &((col("Order_ID")).isNotNull()) 
                                                &((col("Sale_DateTime")).isNotNull()) 
                                                &((col("Customer_ID")).isNotNull()) 
                                                &((col("Product_ID")).isNotNull())  
                                                &((col("Store_ID")).isNotNull()) 
                                                &((col("Quantity")).isNotNull()) 
                                                &((col("Unit_Price")).isNotNull()) 
                                                &((col("Payment_Method")).isNotNull()) 
                                                &((col("Order_Status")).isNotNull())
                                            )
df_sales_valid_records.show()

# COMMAND ----------

df_mandatory_rejected_records = df_sales_clean.filter (
                                                (col("Sale_ID")).isNull()
                                                |(col("Order_ID")).isNull()
                                                |(col("Sale_DateTime")).isNull()
                                                |(col("Customer_ID")).isNull()
                                                |(col("Product_ID")).isNull()
                                                |(col("Store_ID")).isNull()
                                                |(col("Quantity")).isNull()
                                                |((col("Unit_Price")).isNull())
                                                |(col("Payment_Method")).isNull()
                                                |(col("Order_Status")).isNull())
                                                
                                                
df_mandatory_rejected_records.show()
                        

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mandatory Field Validation Summary
# MAGIC ### Checked all mandatory business fields for null values.
# MAGIC ### Identified 769 records with missing mandatory fields.
# MAGIC ### All rejected records contained a missing Payment_Method.
# MAGIC ### Remaining 74,366 records passed mandatory field validation and will continue through the pipeline.

# COMMAND ----------

df_sales_valid_records.filter((col("Unit_Price")<=0) | (col("Quantity") <=0) | (col("Discount_Amount") <0)).count()

# COMMAND ----------

df_sales_valid_records.filter(
    col("Payment_Method").isNull()
).count()

# COMMAND ----------

print(df_sales_valid_records.count())

# COMMAND ----------

df_sales_valid_records.filter(col("Quantity") <= 0).count()

# COMMAND ----------

df_sales_valid_records.filter(col("Unit_Price") <= 0).count()

# COMMAND ----------

df_sales_valid_records.filter(col("Discount_Amount") > 0).count()

# COMMAND ----------

df_sales_valid_records.filter(col("Quantity") <= 0).select(
    "Sale_ID",
    "Quantity",
    "Payment_Method"
).show(20, truncate=False)

# COMMAND ----------

df_sales_valid_records.filter(col("Quantity") < 0) \
    .groupBy("Order_Status") \
    .count() \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Numeric Validations

# COMMAND ----------

df_numeric_valid_records = df_sales_valid_records.filter((col("Quantity")>0) & (col("Unit_Price")>0) & (col("Discount_Amount")>=0))
df_numeric_valid_records.show()

# COMMAND ----------

df_numeric_invalid_records = df_sales_valid_records.filter((col("Quantity")<=0) | (col("Unit_Price")<=0) | (col("Discount_Amount")<0))
df_numeric_invalid_records.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Date Validation

# COMMAND ----------

df_date_validation = df_numeric_valid_records.filter(col("Sale_DateTime") <= current_timestamp())
df_date_validation.count()
df_date_validation.show()

# COMMAND ----------

df_date_invalid_records = df_numeric_valid_records.filter(

    col("Sale_DateTime") > current_timestamp()
)
df_date_invalid_records.count()
df_date_invalid_records.show()

# COMMAND ----------

# Silver Layer Base Path
silver_path = "abfss://silver@stretaillakehouse01.dfs.core.windows.net/"

# COMMAND ----------

# Read Customers Silver
df_silver_customers = (
    spark.read
         .format("parquet")
         .load(silver_path + "customers/")
)

# Read Products Silver
df_silver_products = (
    spark.read
         .format("parquet")
         .load(silver_path + "products/")
)

# Read Stores Silver
df_silver_stores = (
    spark.read
         .format("parquet")
         .load(silver_path + "stores/")
)

# COMMAND ----------

from pyspark.sql.functions import col

df_customer_invalid_records = (
    df_date_validation.alias("l")
    .join(df_silver_customers.alias("r"), col("l.Customer_ID") == col("r.Customer_ID"), how="left_anti")
)
df_customer_invalid_records.show()


# COMMAND ----------

df_customer_invalid_records.count()

# COMMAND ----------

df_customer_invalid_records.select("Customer_ID").distinct().show(20, truncate=False)

# COMMAND ----------

df_silver_customers.count()

# COMMAND ----------

df_silver_customers.select("Customer_ID").distinct().count()

# COMMAND ----------

from pyspark.sql.functions import col

df_customer_valid_records = (
    df_date_validation.alias("l")
    .join(df_silver_customers.alias("r"), col("l.Customer_ID") == col("r.Customer_ID"), how="left_semi")
)
df_customer_valid_records.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product Referential Integrity

# COMMAND ----------

df_invalid_product_records = df_customer_valid_records.alias("l").join(
    df_silver_products.alias("r"), col("l.Product_ID") == col("r.Product_ID"), how="left_anti"
)
df_invalid_product_records.limit(5).show()

# COMMAND ----------

df_valid_product_records = df_customer_valid_records.alias("l").join(
    df_silver_products.alias("r"), col("l.Product_ID") == col("r.Product_ID"), how="left_semi"
)
df_valid_product_records.limit(5).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Store Referential Integrity

# COMMAND ----------

df_invalid_store_records = (
    df_valid_product_records.alias("l")
    .join(
        df_silver_stores.alias("r"),
        col("l.Store_ID") == col("r.Store_ID"),
        how="left_anti"
    )
)
df_invalid_store_records.count()
df_invalid_store_records.show()


# COMMAND ----------

df_valid_store_records = (
    df_valid_product_records.alias("l")
    .join(
        df_silver_stores.alias("r"),
        col("l.Store_ID") == col("r.Store_ID"),
        how="left_semi"
    )
)
df_valid_store_records.count()
df_valid_store_records.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Business Enrichment( Created Gross_Price and Final_Price)

# COMMAND ----------

from pyspark.sql.functions import round
df_gross_price = df_valid_store_records.withColumn("Gross_Price", round(col("Quantity") * col("Unit_Price"), 2))
display(df_gross_price.limit(5))

# COMMAND ----------

from pyspark.sql.functions import round
df_final_price = df_gross_price.withColumn("Final_Price", round(col("Gross_Price") - col("Discount_Amount"), 2))
display(df_final_price.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Domain Validation( Verifying only defined Payment Method & Order Status are present)

# COMMAND ----------

valid_payment_methods = [
    "Cash",
    "UPI",
    "Credit Card",
    "Debit Card",
    "Net Banking"
]

valid_order_status = [
    "Completed",
    "Cancelled"
]

# COMMAND ----------

df_domain_invalid_records = df_final_price.filter(
    (~col("Payment_Method").isin(valid_payment_methods)) |
    (~col("Order_Status").isin(valid_order_status))
)

df_domain_invalid_records.show()


# COMMAND ----------

df_domain_valid_records = df_final_price.filter(
    (col("Payment_Method").isin(valid_payment_methods)) &
    (col("Order_Status").isin(valid_order_status))
)

df_domain_valid_records.show()
df_domain_valid_records.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing into Silver Layer

# COMMAND ----------

(
    df_domain_valid_records.write
        .format("parquet")
        .mode("overwrite")
        .save(silver_path+"sales/")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading from Silver Layer

# COMMAND ----------

df_silver_sales = (
    spark.read
         .format("parquet")
         .load(silver_path + "sales/")
)

# COMMAND ----------

# Row count
df_domain_valid_records.count()
df_silver_sales.count()

# Sample data
df_silver_sales.show(5, truncate=False)

# COMMAND ----------

df_final_price.count()

# COMMAND ----------

df_domain_valid_records.count()

# COMMAND ----------

df_domain_invalid_records.count()

# COMMAND ----------


df_final_price.select("Payment_Method", "Order_Status").distinct().show(truncate=False)

# COMMAND ----------

print("Domain Valid Records:", df_domain_valid_records.count())
print("Silver Records:", df_silver_sales.count())

# COMMAND ----------

df_silver_sales.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation Summary
# MAGIC
# MAGIC - Duplicate Removal
# MAGIC - Mandatory Field Validation
# MAGIC - Numeric Validation
# MAGIC - Date Validation
# MAGIC - Customer Referential Integrity Validation
# MAGIC - Product Referential Integrity Validation
# MAGIC - Store Referential Integrity Validation
# MAGIC - Business Enrichment
# MAGIC - Domain Validation
# MAGIC - Successfully Written to Silver Layer
# MAGIC
# MAGIC **Final Silver Dataset:** 72,445 records