# Databricks notebook source
# MAGIC %md
# MAGIC # Customers Bronze to Silver Transformation
# MAGIC
# MAGIC ## Objective:
# MAGIC
# MAGIC ### Transform Customers Information data from the Bronze layer into the Silver layer by applying data quality validations checks, business rule validations,and before storing the cleansed data in ADLS Gen2.
# MAGIC ### 
# MAGIC ### Source: Bronze (CSV)
# MAGIC ### Destination: Silver (Parquet)
# MAGIC ### 
# MAGIC ### Technologies: Azure Databricks, PySpark, ADLS Gen2, Parquet

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

spark.sql("SHOW CATALOGS").display()

# COMMAND ----------

spark.sql("SHOW EXTERNAL LOCATIONS").display()

# COMMAND ----------

display(dbutils.fs.ls("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/"))

# COMMAND ----------

display(
    dbutils.fs.ls("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/customers/")
)

# COMMAND ----------

display(
    spark.read
         .option("header", "true")
         .csv("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/customers/customers_final.csv")
)

# COMMAND ----------

 from pyspark.sql.types import (
   StructType,
    StructField,
    StringType,
    DateType
 )

customer_schema = StructType([
    StructField("Customer_ID", StringType(), True),
    StructField("First_Name", StringType(), True),
    StructField("Last_Name", StringType(), True),
    StructField("Email", StringType(), True),
    StructField("Country", StringType(), True),
    StructField("City", StringType(), True),
    StructField("Registration_Date", DateType(), True),
    StructField("Customer_Segment", StringType(), True)
])

# COMMAND ----------

display(customer_schema)

# COMMAND ----------

df_customers = (

    spark.read.schema(customer_schema)
    .format("csv")
    .option("header", "true")
    .load("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/customers/customers_final.csv")
)

df_customers.show()
df_customers.printSchema()


# COMMAND ----------

df_totalcount = df_customers.count()
df_totalcount

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Profiling

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null Value Analysis

# COMMAND ----------

df_nullCount = df_customers.filter(col("Email").isNull())
df_nullCount.show()

# COMMAND ----------

df_nullCount.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicate Records Analysis

# COMMAND ----------

df_dupCount = (
    df_customers
        .groupBy("Customer_ID")
        .count()
        .filter(col("count") > 1)
)

df_dupCount.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Observation
# MAGIC
# MAGIC No duplicate Customer_ID records were found in the Customers dataset.
# MAGIC The Customer_ID column satisfies the uniqueness business rule.
# MAGIC No duplicate removal is required before loading data into the Silver layer.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Business Rule Validation
# MAGIC ### 1. No Customer_ID can be null

# COMMAND ----------

df_invalid_CustomerID = df_customers.filter(col("Customer_ID").isNull())
df_invalid_CustomerID.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. First_Name  & Last_Name can't be Null

# COMMAND ----------

df_invalid_first_name = df_customers.filter(col("First_Name").isNull())
df_invalid_first_name.show()

# COMMAND ----------

df_invalid_last_name = df_customers.filter(col("Last_Name").isNull())
df_invalid_last_name.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Customer_Segmentation Cannot be Null

# COMMAND ----------

df_invalid_customer_segmentation = df_customers.filter(col("Customer_Segment").isNull())
df_invalid_customer_segmentation.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ## Observation
# MAGIC ### No Null Customer_Segmentation was found

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.Registration date cannot be greater than current_date

# COMMAND ----------

df_invalid_registration_date = df_customers.filter(df_customers.Registration_Date < current_date())
df_invalid_registration_date.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### All registration date are prior to 30 June 2026

# COMMAND ----------

df_invalid_email = df_customers.filter(col("email").contains("@")).show()

# COMMAND ----------

df_customer_invalid_email= df_customers.filter(~col("Email").contains("@"))
df_customer_invalid_email.show()

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

df_trim_customers = df_customers.withColumn("First_Name", trim(col("First_Name")))\
                        .withColumn("Last_Name", trim(col("Last_Name")))\
                            .withColumn("Email", trim(col("Email")))\
                            .withColumn("Country", trim(col("Country")))\
                            .withColumn("City", trim(col("City")))\
                            .withColumn("Customer_Segment", trim(col("Customer_Segment")))

                        

df_trim_customers.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing the notebook to silver layer

# COMMAND ----------

(
    df_trim_customers.write
        .format("parquet")
        .mode("overwrite")
        .save("abfss://silver@stretaillakehouse01.dfs.core.windows.net/customers/")
)

# COMMAND ----------

df_silver_customers = (
    spark.read
         .format("parquet")
         .load("abfss://silver@stretaillakehouse01.dfs.core.windows.net/customers/")
)

# COMMAND ----------

df_silver_customers.printSchema()

# COMMAND ----------

df_silver_customers.count()

# COMMAND ----------

display(df_silver_customers.limit(20))

# COMMAND ----------

df_customers.count()

# COMMAND ----------

df_silver_customers.count()

# COMMAND ----------

