# Databricks notebook source
# MAGIC %md
# MAGIC # Products Bronze to Silver Transformation
# MAGIC
# MAGIC ## Objective:
# MAGIC
# MAGIC ### Transform Product Information data from the Bronze layer into the Silver layer by applying data quality validations checks, business rule validations,and  before storing the cleansed data in ADLS Gen2.
# MAGIC ### Source: Bronze (CSV)
# MAGIC ### Destination: Silver (Parquet)
# MAGIC ### Technologies: Azure Databricks, PySpark, ADLS Gen2, Parquet

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

display(
    dbutils.fs.ls("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/products/")
)

# COMMAND ----------

display(
    spark.read
         .option("header", "true")
         .csv("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/products/products_final.csv")
)

# COMMAND ----------

product_schema = '''
Product_ID STRING,
Product_Name STRING,
Product_Category STRING,
Product_SubCategory STRING,
Product_Brand STRING,
Product_Price DOUBLE,
Product_Unit STRING,
Product_Launch_Date DATE
'''


# COMMAND ----------

display(product_schema)

# COMMAND ----------

df_products = (

    spark.read.schema(product_schema)
    .format("csv")
    .option("header", "true")
    .load("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/products/products_final.csv")
)

df_products.display()
df_products.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Profiling

# COMMAND ----------

# MAGIC %md
# MAGIC ### Counting total number of products

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

df_product_total_count = df_products.count()
display(df_product_total_count)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null value Analysis

# COMMAND ----------

df_products.columns

# COMMAND ----------

from pyspark.sql.functions import col, count, when

df_total_null_count= df_products.select(
    [
        count(when(col(c).isNull(), c)).alias(c)
        for c in df_products.columns
    ]
)
df_total_null_count.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicate value analysis

# COMMAND ----------

df_dup_product_count = df_products.groupBy("Product_ID").count()
df_dup_product_count = df_dup_product_count.filter(col("count") > 1)
df_dup_product_count.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Business Rule validation

# COMMAND ----------

df_invalid_price_launch_date = df_products.filter((col("Product_Price")<=0) | 
                                       (col("Product_Launch_Date") > current_date()))

display(df_invalid_price_launch_date.limit(20))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation: No invalid product price and launch date were found during operation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Standardization

# COMMAND ----------

# DBTITLE 1,Cell 20
df_trim_products = df_products\
                    .withColumn("Product_ID", trim(col("Product_ID")))\
                    .withColumn("Product_Name", trim(col("Product_Name")))\
                    .withColumn("Product_Category", trim(col("Product_Category")))\
                    .withColumn("Product_SubCategory", trim(col("Product_SubCategory")))\
                    .withColumn("Product_Brand", trim(col("Product_Brand")))\
                    .withColumn("Product_Unit", trim(col("Product_Unit")))
                           

                        

display(df_trim_products.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing in Silver Layer

# COMMAND ----------

(
    df_trim_products.write
        .format("parquet")
        .mode("overwrite")
        .save("abfss://silver@stretaillakehouse01.dfs.core.windows.net/products/")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading for Silver Layer

# COMMAND ----------

df_silver_products = (
    spark.read
         .format("parquet")
         .load("abfss://silver@stretaillakehouse01.dfs.core.windows.net/products/")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### verifying for data loss

# COMMAND ----------

df_silver_products.count()

# COMMAND ----------

df_products.count()

# COMMAND ----------

df_silver_products.printSchema()

# COMMAND ----------

