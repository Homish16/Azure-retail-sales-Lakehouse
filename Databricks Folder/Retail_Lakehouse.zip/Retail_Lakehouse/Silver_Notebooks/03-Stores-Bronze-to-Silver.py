# Databricks notebook source
# MAGIC %md
# MAGIC # Stores Bronze to Silver Transformation
# MAGIC
# MAGIC ## Objective:
# MAGIC ### Transform Stores Information data from the Bronze layer into the Silver layer by applying data quality validations checks, business rule validations,and before storing the cleansed data in ADLS Gen2.
# MAGIC ### Source: Bronze (CSV)
# MAGIC ### Destination: Silver (Parquet)
# MAGIC ### Technologies: Azure Databricks, PySpark, ADLS Gen2, Parquet

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

display(
    spark.read
         .option("header", "true")
         .csv("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/stores/stores_final.csv")
)

# COMMAND ----------

store_schema = '''
Store_ID STRING,
Store_Name STRING,
Country STRING,
State STRING,
City STRING,
Store_Type STRING,
Employee_Count INTEGER,
Opening_Date DATE
'''

# COMMAND ----------

print(store_schema)

# COMMAND ----------

df_stores = spark.read.schema(store_schema)\
            .format("csv").option("header", "true")\
            .load("abfss://bronze@stretaillakehouse01.dfs.core.windows.net/stores/stores_final.csv")

display(df_stores)
df_stores.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Profiling

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null Value analysis

# COMMAND ----------

df_total_null_count= df_stores.select(
    [
        count(when(col(c).isNull(), c)).alias(c)
        for c in df_stores.columns
    ]
)
df_total_null_count.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicate Value analysis

# COMMAND ----------

df_dup_store_count = df_stores.groupBy("Store_ID").count()
df_dup_store_count = df_dup_store_count.filter(col("count") > 1)
df_dup_store_count.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Business rule validation

# COMMAND ----------

df_invalid_store_id = df_stores.filter(col("Store_ID").isNull())
df_invalid_store_id.show()
df_invalid_store_name = df_stores.filter(col("Store_Name").isNull())
df_invalid_store_name.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### verifying if all columns are not null

# COMMAND ----------

df_invalid_store_details = df_stores.filter(

    col("Store_ID").isNull() |
    col("Store_Name").isNull() |
    col("Country").isNull() |
    col("State").isNull() |
    col("City").isNull() |
    col("Store_Type").isNull()
)

df_invalid_store_details.show()

# COMMAND ----------

df_valid_emp_count = df_stores.filter(col("Employee_Count").isNull())
df_valid_emp_count.show()


    

# COMMAND ----------

df_valid_launch_date = df_stores.filter(col("Opening_Date") < current_date())
df_valid_launch_date.show()

# COMMAND ----------

df_trim_stores = df_stores\
                    .withColumn("Store_ID", trim(col("Store_ID")))\
                    .withColumn("Store_Name", trim(col("Store_Name")))\
                    .withColumn("Country", trim(col("Country")))\
                    .withColumn("State", trim(col("State")))\
                    .withColumn("City", trim(col("City")))\
                    .withColumn("Store_Type", trim(col("Store_Type")))\
                   
                           

                        

display(df_trim_stores.limit(10))

# COMMAND ----------

df_silver_stores = (
    df_trim_stores.write
        .format("parquet")
        .mode("overwrite")
        .save("abfss://silver@stretaillakehouse01.dfs.core.windows.net/stores/")
)

# COMMAND ----------

df_silver_stores = (
    spark.read
         .format("parquet")
         .load("abfss://silver@stretaillakehouse01.dfs.core.windows.net/stores/")
)

# COMMAND ----------

df_silver_stores.display()
df_silver_stores.printSchema()

# COMMAND ----------

df_silver_stores.count()

# COMMAND ----------

df_stores.count()

# COMMAND ----------

