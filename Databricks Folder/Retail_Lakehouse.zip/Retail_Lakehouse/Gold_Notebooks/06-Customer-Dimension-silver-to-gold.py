# Databricks notebook source
# MAGIC %md
# MAGIC ### Importing

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Base Paths
SILVER_BASE_PATH = "abfss://silver@stretaillakehouse01.dfs.core.windows.net/"
GOLD_BASE_PATH   = "abfss://gold@stretaillakehouse01.dfs.core.windows.net/"

# Source Path
SILVER_CUSTOMER_PATH = SILVER_BASE_PATH + "customers/"

# Target Path
GOLD_DIM_CUSTOMER_PATH = GOLD_BASE_PATH + "dim_customer/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading from silver layer

# COMMAND ----------

df_dim_customer = (
    spark.read
         .format("parquet")
         .load(SILVER_CUSTOMER_PATH)
)

# COMMAND ----------

df_dim_customer.printSchema()
df_dim_customer.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Row counting 

# COMMAND ----------

df_dim_customer.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null value analysis: We kept the null as we don't have any business requirement but in production environment, it depends upon the requirement

# COMMAND ----------

df_dim_customer.select(
    *[
        sum(col(c).isNull().cast("int")).alias(c)
        for c in df_dim_customer.columns
    ]
).show()

# COMMAND ----------

df_dim_customer.filter(col("Email").isNull()).show(10, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicate Detection verification

# COMMAND ----------

(df_dim_customer
.groupBy("Customer_ID")
.count()
.filter(col("count")>1).show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Observation
# MAGIC ### No duplicate value were found in the dataset

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing to gold layer

# COMMAND ----------

(df_dim_customer.write
 .mode("overwrite")
 .format("parquet")
 .save(GOLD_DIM_CUSTOMER_PATH)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading for gold layer

# COMMAND ----------

df_gold_dim_customer = (
    spark.read
    .format("parquet")
    .load(GOLD_DIM_CUSTOMER_PATH)
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Final verification

# COMMAND ----------

df_gold_dim_customer.printSchema()

df_gold_dim_customer.show(10, truncate=False)

print(f"Gold Row Count: {df_gold_dim_customer.count()}")

# COMMAND ----------

