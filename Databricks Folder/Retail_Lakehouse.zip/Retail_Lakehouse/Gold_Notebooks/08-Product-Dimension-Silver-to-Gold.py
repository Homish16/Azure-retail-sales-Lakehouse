# Databricks notebook source
# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ## Base Path

# COMMAND ----------

# Base Paths
SILVER_BASE_PATH = "abfss://silver@stretaillakehouse01.dfs.core.windows.net/"
GOLD_BASE_PATH   = "abfss://gold@stretaillakehouse01.dfs.core.windows.net/"

# Source Path
SILVER_PRODUCT_PATH = SILVER_BASE_PATH + "products/"

# Target Path
GOLD_DIM_PRODUCT_PATH = GOLD_BASE_PATH + "dim_product/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading from Silver Layer

# COMMAND ----------

df_dim_product = (
    spark.read
         .format("parquet")
         .load(SILVER_PRODUCT_PATH)
)

# COMMAND ----------

df_dim_product.printSchema()

df_dim_product.show(5, truncate=False)

print(f"Total Rows: {df_dim_product.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null Value Verification

# COMMAND ----------

df_dim_product.select(
    [
        sum(col(c).isNull().cast("int")).alias(c)
        for c in df_dim_product.columns
    ]
).show()

# COMMAND ----------

df_dim_product.filter("Product_Brand IS NULL").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Observation:
# MAGIC ### Product_Brand has 14 NULL values.
# MAGIC ### No imputation performed as no business rule or trusted reference data is available.

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Duplicate Value Verification

# COMMAND ----------

df_duplicate_products = (
    df_dim_product
    .groupBy("Product_ID")
    .count()
    .filter(col("count") > 1)
)

df_duplicate_products.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation for Derived Column

# COMMAND ----------

df_dim_product.select("Product_Price").summary().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating Derived Column Price_Category

# COMMAND ----------

df_dim_product = (
    df_dim_product
    .withColumn(
        "Price_Category",
        when(col("Product_Price") <= 12369.98, "Budget")
        .when(col("Product_Price") <= 24214.88, "Standard")
        .when(col("Product_Price") <= 37775.67, "Premium")
        .otherwise("Luxury")
    )
)

# COMMAND ----------

df_product_validation = df_dim_product.select("Product_Name","Product_ID","Price_Category")
display(df_product_validation.limit(10))

# COMMAND ----------

df_dim_product.groupBy("Price_Category").count().show()

# COMMAND ----------

(
    df_dim_product.write
    .mode("overwrite")
    .format("parquet")
    .save(GOLD_DIM_PRODUCT_PATH)
)

# COMMAND ----------

df_dim_gold_product = (
    spark.read
         .format("parquet")
         .load(GOLD_DIM_PRODUCT_PATH)
)
df_dim_gold_product.printSchema()

df_dim_gold_product.show(5, truncate=False)


# COMMAND ----------

