# Databricks notebook source
# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# Base Paths
SILVER_BASE_PATH = "abfss://silver@stretaillakehouse01.dfs.core.windows.net/"
GOLD_BASE_PATH   = "abfss://gold@stretaillakehouse01.dfs.core.windows.net/"

# Source Path
SILVER_STORE_PATH = SILVER_BASE_PATH + "stores/"

# Target Path
GOLD_DIM_STORE_PATH = GOLD_BASE_PATH + "dim_store/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading from Silver Layer

# COMMAND ----------

df_dim_store = (
    spark.read
         .format("parquet")
         .load(SILVER_STORE_PATH)
)

# COMMAND ----------

df_dim_store.printSchema()

df_dim_store.show(5, truncate=False)

print(f"Total Rows: {df_dim_store.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null Value Evaluation

# COMMAND ----------

df_dim_store.select(
    [
        sum(col(c).isNull().cast("int")).alias(c)
        for c in df_dim_store.columns
    ]
).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicate Value Evaluation

# COMMAND ----------

(
    df_dim_store
    .groupBy("Store_ID")
    .count()
    .filter(col("count") > 1)
    .show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing to Gold Layer

# COMMAND ----------

(
    df_dim_store.write
    .mode("overwrite")
    .format("parquet")
    .save(GOLD_DIM_STORE_PATH)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading from Gold Layer

# COMMAND ----------

df_gold_dim_store = (
    spark.read
         .format("parquet")
         .load(GOLD_DIM_STORE_PATH)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation

# COMMAND ----------

df_gold_dim_store.printSchema()

df_gold_dim_store.show(10, truncate=False)

print(f"Gold Row Count: {df_gold_dim_store.count()}")

# COMMAND ----------

