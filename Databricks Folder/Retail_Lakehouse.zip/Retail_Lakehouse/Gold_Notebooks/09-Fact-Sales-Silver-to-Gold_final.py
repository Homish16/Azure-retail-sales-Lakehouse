# Databricks notebook source
# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setting up Base paths

# COMMAND ----------

# Base Paths
SILVER_BASE_PATH = "abfss://silver@stretaillakehouse01.dfs.core.windows.net/"
GOLD_BASE_PATH   = "abfss://gold@stretaillakehouse01.dfs.core.windows.net/"
GOLD_DIM_CUSTOMER_PATH = GOLD_BASE_PATH + "dim_customer/"
GOLD_DIM_PRODUCT_PATH = GOLD_BASE_PATH + "dim_product/"
GOLD_DIM_STORE_PATH = GOLD_BASE_PATH + "dim_store/"
GOLD_DIM_DATE_PATH = GOLD_BASE_PATH + "dim_date/"

# Source Path
SILVER_SALES_PATH = SILVER_BASE_PATH + "sales/"

# Target Path
GOLD_FACT_SALES_PATH = GOLD_BASE_PATH + "fact_sales/"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading Data from Silver Layer

# COMMAND ----------

df_fact_sales = (spark.read.format("parquet").load(SILVER_SALES_PATH))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Checking Schema,counting records,displaying base data

# COMMAND ----------

df_fact_sales.printSchema()
df_fact_sales.show(5, truncate=False)
print(f"Total records: {df_fact_sales.count()}")

# COMMAND ----------

display(df_fact_sales.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Null Value Verification

# COMMAND ----------

df_fact_sales.select(
    [
        sum(col(c).isNull().cast("int")).alias(c)
        for c in df_fact_sales.columns
    ]
).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation: No null values were found in dataset

# COMMAND ----------

# MAGIC %md
# MAGIC ## Duplicate Value Verification

# COMMAND ----------

df_fact_sales_duplicate = df_fact_sales.groupBy("Sale_ID").count().filter(col("count")>1)
df_fact_sales_duplicate.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gross Price Verification

# COMMAND ----------

df_invalid_gross_price = df_fact_sales.filter(round(col("Quantity") * col("Unit_Price"),2) != round(col("Gross_Price"),2))
df_invalid_gross_price.show(10)
df_invalid_gross_price.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Initial validation identified 8,666 records where
# MAGIC ### Quantity × Unit_Price ≠ Gross_Price.
# MAGIC ### 
# MAGIC ### Upon investigation, sample records showed the calculated
# MAGIC ### and stored values were visually identical.
# MAGIC ### 
# MAGIC ### Root Cause:
# MAGIC ### The mismatch was caused by floating-point precision
# MAGIC ### (`double` data type), resulting in minor binary decimal differences.
# MAGIC ### 
# MAGIC ### Resolution:
# MAGIC ### Rounded both calculated and stored values to two decimal places
# MAGIC ### before comparison.
# MAGIC ### 
# MAGIC ### Final Result:
# MAGIC ### 0 invalid records found.
# MAGIC ### Business rule successfully validated.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Final Price verification

# COMMAND ----------

df_invalid_final_price = df_fact_sales.filter(round(col("Gross_Price")-col("Discount_Amount"),2) != round(col("Final_Price"),2))
df_invalid_final_price.show(10)
df_invalid_final_price.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation: Using above method here, No invalid final price were found

# COMMAND ----------

# MAGIC %md
# MAGIC ## Referential Integrity Validation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading the customer dimension notebook for customer_id from there

# COMMAND ----------

df_dim_customer = (
    spark.read
         .format("parquet")
         .load(GOLD_DIM_CUSTOMER_PATH)
)

# COMMAND ----------

df_invalid_customer_fk = (
    df_fact_sales
    .join(df_dim_customer,
    on="customer_id", 
    how= "left_anti")
)

# COMMAND ----------

df_invalid_customer_fk.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation: No invalid customer_id was found

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading the Product Notebook for product_id

# COMMAND ----------

df_dim_product = (
    spark.read
         .format("parquet")
         .load(GOLD_DIM_PRODUCT_PATH)
)

# COMMAND ----------

df_invalid_product_fk = (
    df_fact_sales
    .join(df_dim_product,
    on="product_id", 
    how= "left_anti")
)

# COMMAND ----------

df_invalid_product_fk.show()

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Observation: No invalid product_id was found.

# COMMAND ----------

df_dim_store = (
    spark.read
         .format("parquet")
         .load(GOLD_DIM_STORE_PATH)
)

# COMMAND ----------

df_invalid_store_fk = (
    df_fact_sales
    .join(df_dim_store,
    on="store_id", 
    how= "left_anti")
)

# COMMAND ----------

df_invalid_store_fk.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation: No invalid store_id was found

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating a derived column Date_Key for joining the dim_date table

# COMMAND ----------

from pyspark.sql.functions import date_format
df_fact_sales = (

    df_fact_sales
        .withColumn(
            "Date_Key",
            date_format("Sale_DateTime", "yyyyMMdd").cast("int")
        )
)

df_fact_sales.show()

# COMMAND ----------

df_dim_date = (
    spark.read
         .format("parquet")
         .load(GOLD_DIM_DATE_PATH)
)

# COMMAND ----------

df_invalid_date_key_fk = (
    df_fact_sales
    .join(df_dim_date,
          on="Date_key", how= "left_anti")
)

# COMMAND ----------

df_invalid_date_key_fk.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation: No invalid date_key found

# COMMAND ----------

# MAGIC %md
# MAGIC ## Created derived column Discount_Percentage

# COMMAND ----------

# DBTITLE 1,Cell 35
from pyspark.sql.functions import when, col, round
df_fact_sales = df_fact_sales.withColumn(
    "Discount_Percentage",
    when(
        col("Gross_Price")>0,
        round(col("Discount_Amount")/col("Gross_Price")*100, 2)
    ).otherwise(0)
)

# COMMAND ----------

df_fact_sales.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Created Derived column Discount_Flag

# COMMAND ----------

df_fact_sales= df_fact_sales.withColumn("Discount_Flag", when(col("Discount_Percentage")>0, "Yes").otherwise("No"))
df_fact_sales.display()

# COMMAND ----------

df_fact_sales.groupBy("Discount_Flag").count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observation:The majority of transactions (99.61%) received a discount, while 283 transactions (0.39%) were completed without any discount. This validates the usefulness of the Discount_Flag attribute for downstream business analysis.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing to Gold Layer

# COMMAND ----------

(
    df_fact_sales.write
    .mode("overwrite")
    .format("parquet")
    .save(GOLD_FACT_SALES_PATH)
)

# COMMAND ----------

df_fact_gold_sales = spark.read.format("parquet").load(GOLD_FACT_SALES_PATH)
display(df_fact_gold_sales.limit(10))
df_fact_gold_sales.count()
df_fact_gold_sales.printSchema()

# COMMAND ----------

