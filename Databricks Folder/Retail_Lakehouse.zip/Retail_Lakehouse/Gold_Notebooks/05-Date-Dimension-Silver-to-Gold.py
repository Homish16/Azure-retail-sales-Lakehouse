# Databricks notebook source
# MAGIC %md
# MAGIC ##  ======================================================
# MAGIC ##  Notebook  : 05-Date-Dimension-Silver-to-Gold
# MAGIC ## Layer     : Silver → Gold
# MAGIC ## Purpose   : Generate reusable Date Dimension
# MAGIC ## Author    : Homish Bhange
# MAGIC ## ======================================================
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###Imports

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ## ==========================================
# MAGIC ## Configuration
# MAGIC ## ==========================================

# COMMAND ----------

# Base Paths
SILVER_BASE_PATH = "abfss://silver@stretaillakehouse01.dfs.core.windows.net/"
GOLD_BASE_PATH   = "abfss://gold@stretaillakehouse01.dfs.core.windows.net/"

# Source Paths
SILVER_SALES_PATH = SILVER_BASE_PATH + "sales/"

# Target Paths
GOLD_DIM_DATE_PATH = GOLD_BASE_PATH + "dim_date/"

# COMMAND ----------

# MAGIC %md
# MAGIC ## ======================================================
# MAGIC ## Read Silver Sales Data
# MAGIC ## ======================================================

# COMMAND ----------


df_silver_sales = (
    spark.read
         .format("parquet")
         .load(SILVER_SALES_PATH)
)

# COMMAND ----------

# Display sample records
display(df_silver_sales)

# COMMAND ----------

# Display schema
df_silver_sales.printSchema()

# COMMAND ----------

# Display record count
print(f"Total Records: {df_silver_sales.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Finding the mininum and maximum calender dates

# COMMAND ----------

from pyspark.sql.functions import min, max

df_date_range = (
    df_silver_sales
        .agg(
            min("Sale_DateTime").alias("Min_Sale_DateTime"),
            max("Sale_DateTime").alias("Max_Sale_DateTime")
        )
)

# COMMAND ----------

df_date_range.show()

# COMMAND ----------

min_sale_date = date_range.Min_Sale_DateTime
max_sale_date = date_range.Max_Sale_DateTime

print(min_sale_date)
print(max_sale_date)

# COMMAND ----------

min_date = min_sale_date.date()
max_date = max_sale_date.date()

# COMMAND ----------

from pyspark.sql.functions import min, max, sequence, explode, to_date

df_date_range = (
    df_silver_sales
    .agg(
        to_date(min("Sale_DateTime")).alias("min_date"),
        to_date(max("Sale_DateTime")).alias("max_date")
    )
)

# COMMAND ----------

df_date_range.display()

# COMMAND ----------

df_dim_date = (
    df_date_range
    .select(
        explode(
            sequence("min_date", "max_date")
        ).alias("Date")
    )
)

# COMMAND ----------

df_dim_date.show(10, truncate=False)

# COMMAND ----------

df_format_date =(
    df_dim_date
    .withColumn(
        "Date_Key",
        date_format("Date", "yyyyMMdd").cast("int")
    )
)

# COMMAND ----------

df_format_date.show(5, truncate=False)

# COMMAND ----------

df_format_date.printSchema()

# COMMAND ----------

df_date_dim = (
    df_format_date.withColumn("Year",year(col("Date")))\
        .withColumn("Quarter",quarter(col("Date")))\
        .withColumn("Month_Number",month(col("Date")))\
        .withColumn("Year_Month", date_format(col("Date"), "MMM yyyy"))\
        .withColumn("Year_Month_Key", date_format(col("Date"), "yyyyMM").cast("int"))
        .withColumn("Week_Number", weekofyear(col("Date")))\
        .withColumn("Day_Number",dayofmonth("Date"))\
        .withColumn("Month_Name",date_format(col("Date"),"MMMM"))\
        .withColumn("Day_Name",date_format(col("Date"),"EEEE"))
     
)

# COMMAND ----------

display(df_date_dim)

# COMMAND ----------

df_is_weekend = (
    df_date_dim
    .withColumn(
        "Is_Weekend",
        when(col("Day_Name") == "Saturday", "Y")
        .when(col("Day_Name") == "Sunday","Y").otherwise("N")))

df_is_weekend.show(10)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Check

# COMMAND ----------

print(f"Total Rows: {df_is_weekend.count()}")

df_is_weekend.printSchema()

df_is_weekend.show(10, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Null Value Identification

# COMMAND ----------

df_is_weekend.select(
    *[
        sum(col(c).isNull().cast("int")).alias(c)
        for c in df_is_weekend.columns
    ]
).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Duplicate Date Verification

# COMMAND ----------

(
    df_is_weekend
    .groupBy("Date")
    .count()
    .filter(col("count") > 1)
    .show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing the notebook in Gold Layer

# COMMAND ----------

(
    df_is_weekend.write
    .mode("overwrite")
    .format("parquet")
    .save(GOLD_DIM_DATE_PATH)
)

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ### Reading from Gold Layer

# COMMAND ----------

df_gold_dim_date = (
    spark.read
    .format("parquet")
    .load(GOLD_DIM_DATE_PATH)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Validation

# COMMAND ----------

df_gold_dim_date.printSchema()
df_gold_dim_date.show(10, truncate=False)
print(df_gold_dim_date.count())

# COMMAND ----------

